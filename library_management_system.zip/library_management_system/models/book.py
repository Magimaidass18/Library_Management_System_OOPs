from datetime import datetime

class Book:
    def __init__(self, title, author, isbn, copies):
        self.title = title
        self.author = author
        self.isbn = isbn
        self.copies = copies
        self.checked_out = False
        self.checked_out_by = None
        self.checked_out_time = None

    def to_dict(self):
        return {
            'title': self.title,
            'author': self.author,
            'isbn': self.isbn,
            'copies': self.copies
        }

    @classmethod
    def from_dict(cls, data):
        title = data.get('title')
        author = data.get('author')
        isbn = data.get('isbn')
        copies = data.get('copies')
        return cls(title, author, isbn, copies)
    
    def check_out(self, user):
        if self.checked_out:
            raise ValueError("This book is already checked out.")
        self.checked_out = True
        self.checked_out_by = user
        self.checked_out_time = datetime.now()
        user.check_out_book(self)

    def check_in(self):
        if not self.checked_out:
            raise ValueError("This book is already checked in.")
        self.checked_out = False
        self.checked_out_by.check_in_book(self)
        self.checked_out_by = None
        self.checked_out_time = None