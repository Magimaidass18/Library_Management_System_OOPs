import logging

class User:
    def __init__(self, name, user_id):
        self.name = name
        self.user_id = user_id
        self.books_checked_out = [] 

    def to_dict(self):
        return {
            'name': self.name,
            'user_id': self.user_id
        }

    # @classmethod
    # def from_dict(cls, data):
    #     return cls(data['name'], data['user_id'])
    
    @classmethod
    def from_dict(cls, data):
        name = data.get('name')
        user_id = data.get('user_id')
        return cls(name, user_id)
    
    def check_out_book(self, book):
        self.books_checked_out.append(book)
        logging.info(f"{self.name} checked out the book '{book.title}' (ISBN: {book.isbn}).")

    def check_in_book(self, book):
        self.books_checked_out.remove(book)
        logging.info(f"{self.name} checked in the book '{book.title}' (ISBN: {book.isbn}).")