import json

class StorageHandler:
    def __init__(self, filename):
        self.filename = filename

    def _read_data(self):
        try:
            with open(self.filename, 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            return {}

    def _write_data(self, data):
        with open(self.filename, 'w') as file:
            json.dump(data, file, indent=4)

    def save_data(self, key, value):
        data = self._read_data()
        data[key] = value
        self._write_data(data)

    def update_data(self, key, updated_value):
        data = self._read_data()
        if key in data:
            data[key] = updated_value
            self._write_data(data)
        else:
            raise KeyError(f"Key {key} not found.")

    def delete_data(self, key):
        data = self._read_data()
        if key in data:
            del data[key]
            self._write_data(data)
        else:
            raise KeyError(f"Key {key} not found.")

    def get_all_data(self):
        return list(self._read_data().values())

    def search_data(self, search_criteria):
        data = self._read_data()
        return [value for value in data.values() if all(criteria in str(value) for criteria in search_criteria)]
    

    def get_data(self, key):
        data = self._read_data()
        return data.get(key)