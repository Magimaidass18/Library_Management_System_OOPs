from models.book import Book
from storage.storage_handler import StorageHandler
from datetime import datetime

class BookManager:
    def __init__(self):
        self.storage_handler = StorageHandler('books.json')

    def add_book(self, book):
        self.storage_handler.save_data(book.isbn, book.to_dict())

    # def update_book(self, isbn, updated_book_data):
    #     self.storage_handler.update_data(isbn, updated_book_data)

    def delete_book(self, isbn):
        self.storage_handler.delete_data(isbn)

    def list_books(self):
        return [Book.from_dict(data) for data in self.storage_handler.get_all_data()]

    def search_books(self, search_criteria):
        return [Book.from_dict(data) for data in self.storage_handler.search_data(search_criteria)]
    
    def update_book(self, isbn, updated_book_data):
        if not updated_book_data:
            raise ValueError("No data provided for updating the book.")
        
        book_data = self.storage_handler.get_data(isbn)
        if not book_data:
            raise KeyError(f"Book with ISBN {isbn} not found.")
        
        updated_data = {**book_data, **updated_book_data}
        self.storage_handler.update_data(isbn, updated_data)

    def check_out_book(self, isbn, user):
        book = self.get_book(isbn)
        if book:
            book.check_out(user)
            self.update_book(isbn, book.to_dict())
        else:
            raise KeyError(f"Book with ISBN {isbn} not found.")

    def check_in_book(self, isbn):
        book = self.get_book(isbn)
        if book:
            book.check_in()
            self.update_book(isbn, book.to_dict())
        else:
            raise KeyError(f"Book with ISBN {isbn} not found.")
        
    def is_book_available(self, isbn):
        book = self.get_book(isbn)
        if book:
            return not book.checked_out
        else:
            raise KeyError(f"Book with ISBN {isbn} not found.")
        
    def get_book(self, isbn):
        books = self.list_books()
        for book in books:
            if book.isbn == isbn:
                return book
        return None