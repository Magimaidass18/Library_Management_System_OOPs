from models.user import User
from storage.storage_handler import StorageHandler

class UserManager:
    def __init__(self,book_manager):
        self.storage_handler = StorageHandler('users.json')
        self.book_manager = book_manager

    def add_user(self, user):
        self.storage_handler.save_data(user.user_id, user.to_dict())

    # def update_user(self, user_id, updated_user_data):
    #     self.storage_handler.update_data(user_id, updated_user_data)

    def delete_user(self, user_id):
        self.storage_handler.delete_data(user_id)

    def list_users(self):
        return [User.from_dict(data) for data in self.storage_handler.get_all_data()]

    def search_users(self, search_criteria):
        return [User.from_dict(data) for data in self.storage_handler.search_data(search_criteria)]
    
    def update_user(self, user_id, updated_user_data):
        if not updated_user_data:
            raise ValueError("No data provided for updating the user.")
        
        user_data = self.storage_handler.get_data(user_id)
        if not user_data:
            raise KeyError(f"User with ID {user_id} not found.")
        
        updated_data = {**user_data, **updated_user_data}
        self.storage_handler.update_data(user_id, updated_data)

    def get_user_books_count(self, user_id):
        user = self.get_user(user_id)
        if user:
            checked_out_count = len(user.books_checked_out)
            checked_in_count = len([book for book in self.book_manager.list_books() if book.checked_out_by == user and not book.checked_out])
            return checked_out_count + checked_in_count
        else:
            raise KeyError(f"User with ID {user_id} not found.")
        
    def get_user(self, user_id):
        users = self.list_users()
        for user in users:
            if user.user_id == user_id:
                return user
        return None