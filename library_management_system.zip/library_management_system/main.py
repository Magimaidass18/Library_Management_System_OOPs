import logging

# Configure logging
logging.basicConfig(filename='library.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

from managers.book_manager import BookManager
from managers.user_manager import UserManager
from models.book import Book
from models.user import User

class LibraryManagementSystem:
    def __init__(self, book_manager, user_manager):
        self.book_manager = book_manager
        self.user_manager = user_manager

    def main_menu(self):
        while True:
            print("Library Management System")
            print("1. Manage Books")
            print("2. Manage Users")
            print("3. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.book_menu()
            elif choice == '2':
                self.user_menu()
            elif choice == '3':
                print("Exiting program.")
                break
            else:
                print("Invalid choice. Please try again.")

    def book_menu(self):
        while True:
            print("\nBook Menu")
            print("1. Add Book")
            print("2. Update Book")
            print("3. Delete Book")
            print("4. List Books")
            print("5. Search Books")
            print("6. Back to Main Menu")
            print("7. Check Out Book")
            print("8. Check In Book")
            print("9. Check User Books Count")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.add_book()
            elif choice == '2':
                self.update_book()
            elif choice == '3':
                self.delete_book()
            elif choice == '4':
                self.list_books()
            elif choice == '5':
                self.search_books()
            elif choice == '6':
                break
            elif choice == '7':
                self.check_out_book()
            elif choice == '8':
                self.check_in_book()
            elif choice == '9':
                self.check_user_books_count()
            else:
                print("Invalid choice. Please try again.")

    def check_out_book(self):
        isbn = input("Enter ISBN of the book to check out: ")
        user_id = input("Enter user ID: ")
        try:
            self.book_manager.check_out_book(isbn, user_id)
            print("Book checked out successfully.")
        except Exception as e:
            print(f"Error: {str(e)}")

    def check_in_book(self):
        isbn = input("Enter ISBN of the book to check in: ")
        try:
            self.book_manager.check_in_book(isbn)
            print("Book checked in successfully.")
        except Exception as e:
            print(f"Error: {str(e)}")

    def add_book(self):
        title = input("Enter book title: ")
        author = input("Enter author name: ")
        isbn = input("Enter ISBN: ")
        copies = int(input("Enter number of copies: "))

        book = Book(title, author, isbn, copies)
        self.book_manager.add_book(book)
        print("Book added successfully.")

    def update_book(self):
        isbn = input("Enter ISBN of the book to update: ")
        updated_title = input("Enter updated title (leave empty to keep unchanged): ")
        updated_author = input("Enter updated author (leave empty to keep unchanged): ")
        updated_copies = input("Enter updated number of copies (leave empty to keep unchanged): ")

        updated_book_data = {}
        if updated_title:
            updated_book_data['title'] = updated_title
        if updated_author:
            updated_book_data['author'] = updated_author
        if updated_copies:
            updated_book_data['copies'] = int(updated_copies)

        self.book_manager.update_book(isbn, updated_book_data)
        print("Book updated successfully.")

    def delete_book(self):
        isbn = input("Enter ISBN of the book to delete: ")
        self.book_manager.delete_book(isbn)
        print("Book deleted successfully.")

    def list_books(self):
        books = self.book_manager.list_books()
        if books:
            for index, book in enumerate(books, start=1):
                print(f"{index}. Title: {book.title}, Author: {book.author}, ISBN: {book.isbn}, Copies: {book.copies}")
        else:
            print("No books available.")

    def search_books(self):
        search_criteria = input("Enter search criteria: ")
        books = self.book_manager.search_books(search_criteria)
        if books:
            for index, book in enumerate(books, start=1):
                print(f"{index}. Title: {book.title}, Author: {book.author}, ISBN: {book.isbn}, Copies: {book.copies}")
        else:
            print("No matching books found.")

    def user_menu(self):
        while True:
            print("\nUser Menu")
            print("1. Add User")
            print("2. Update User")
            print("3. Delete User")
            print("4. List Users")
            print("5. Search Users")
            print("6. Back to Main Menu")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.add_user()
            elif choice == '2':
                self.update_user()
            elif choice == '3':
                self.delete_user()
            elif choice == '4':
                self.list_users()
            elif choice == '5':
                self.search_users()
            elif choice == '6':
                break
            else:
                print("Invalid choice. Please try again.")

    def add_user(self):
        name = input("Enter user name: ")
        user_id = input("Enter user ID: ")

        user = User(name, user_id)
        self.user_manager.add_user(user)
        print("User added successfully.")

    def update_user(self):
        user_id = input("Enter ID of the user to update: ")
        updated_name = input("Enter updated name (leave empty to keep unchanged): ")

        updated_user_data = {}
        if updated_name:
            updated_user_data['name'] = updated_name

        self.user_manager.update_user(user_id, updated_user_data)
        print("User updated successfully.")

    def delete_user(self):
        user_id = input("Enter ID of the user to delete: ")
        self.user_manager.delete_user(user_id)
        print("User deleted successfully.")

    def check_user_books_count(self):
        user_id = input("Enter user ID to check the number of books: ")
        try:
            count = self.user_manager.get_user_books_count(user_id)
            print(f"The user with ID {user_id} has checked out {count} books.")
        except Exception as e:
            print(f"Error: {str(e)}")

    def list_users(self):
        users = self.user_manager.list_users()
        if users:
            for index, user in enumerate(users, start=1):
                print(f"{index}. Name: {user.name}, ID: {user.user_id}")
        else:
            print("No users available.")

    def search_users(self):
        search_criteria = input("Enter search criteria: ")
        users = self.user_manager.search_users(search_criteria)
        if users:
            for index, user in enumerate(users, start=1):
                print(f"{index}. Name: {user.name}, ID: {user.user_id}")
        else:
            print("No matching users found.")

if __name__ == "__main__":
    book_manager = BookManager()
    user_manager = UserManager(book_manager)
    lms = LibraryManagementSystem(book_manager, user_manager)
    lms.main_menu()